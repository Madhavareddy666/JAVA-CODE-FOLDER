public class Q36 {
    interface Notification { void remind(String message); }
    static class ConsoleNotification implements Notification {
        public void remind(String message){System.out.println("Console reminder: "+message);}
    }
    static class EmailNotification implements Notification {
        public void remind(String message){System.out.println("Email reminder: "+message);}
    }
    static void sendReminder(Notification notification,String message){notification.remind(message);}
    public static void main(String[] args) {
        sendReminder(new ConsoleNotification(),"Submit the Java practical record.");
        sendReminder(new EmailNotification(),"Submit the Java practical record.");
    }
}
