public class Q31 {
    interface Exporter { void export(String data); }
    static class CSVExporter implements Exporter {
        public void export(String data){System.out.println("CSV export: "+data.replace("|",","));}
    }
    static class JSONExporter implements Exporter {
        public void export(String data){String[] p=data.split("\\\\|");System.out.println("JSON export: {\\\"name\\\":\\\""+p[0]+"\\\",\\\"score\\\":\\\""+p[1]+"\\\"}");}
    }
    public static void main(String[] args) {
        Exporter[] exporters={new CSVExporter(),new JSONExporter()};
        for(Exporter e:exporters)e.export("Madhava|95");
    }
}
