public class Q21 {
    static class Employee {
        String name; double salary;
        Employee(String name,double salary){this.name=name;this.salary=salary;}
        void display(){System.out.println("Name: "+name+"\nSalary: "+salary);}
    }
    static class Manager extends Employee {
        int teamSize;
        Manager(String name,double salary,int teamSize){super(name,salary);this.teamSize=teamSize;}
        double bonus(){return salary;}
        @Override void display(){super.display();System.out.println("Team size: "+teamSize+"\nBonus: "+bonus());}
    }
    public static void main(String[] args){new Manager("Meera",60000,8).display();}
}
