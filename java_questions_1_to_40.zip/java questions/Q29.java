public class Q29 {
    static abstract class Worker { String name; Worker(String n){name=n;} abstract double calculatePay(); }
    static class SalariedWorker extends Worker {
        double monthlySalary; SalariedWorker(String n,double s){super(n);monthlySalary=s;}
        double calculatePay(){return monthlySalary;}
    }
    static class HourlyWorker extends Worker {
        double hourlyRate,hours; HourlyWorker(String n,double r,double h){super(n);hourlyRate=r;hours=h;}
        double calculatePay(){return hourlyRate*hours;}
    }
    public static void main(String[] args) {
        Worker[] workers={new SalariedWorker("Ravi",50000),new HourlyWorker("Kiran",300,160)};
        for(Worker w:workers)System.out.printf("%s payroll: %.2f%n",w.name,w.calculatePay());
    }
}
