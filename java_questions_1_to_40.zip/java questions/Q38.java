public class Q38 {
    static abstract class Account {
        double balance; Account(double b){balance=b;}
        abstract double monthlyInterest();
    }
    static class SavingsAccount extends Account {
        SavingsAccount(double b){super(b);}
        double monthlyInterest(){return balance*0.04/12;}
    }
    static class FixedDepositAccount extends Account {
        FixedDepositAccount(double b){super(b);}
        double monthlyInterest(){return balance*0.07/12;}
    }
    public static void main(String[] args) {
        System.out.printf("Savings monthly interest: %.2f%n",new SavingsAccount(100000).monthlyInterest());
        System.out.printf("Fixed deposit monthly interest: %.2f%n",new FixedDepositAccount(100000).monthlyInterest());
    }
}
