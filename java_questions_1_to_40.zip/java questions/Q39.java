import java.util.HashMap;
import java.util.Map;
public class Q39 {
    static class Storage {
        private final Map<String,String> data=new HashMap<>();
        void save(String key,String value){data.put(key,value);System.out.println("Saved: "+key);}
        String load(String key){return data.getOrDefault(key,"Key not found");}
    }
    public static void main(String[] args) {
        Storage storage=new Storage();
        storage.save("name","Madhava");storage.save("course","Java");
        System.out.println("name = "+storage.load("name"));
        System.out.println("course = "+storage.load("course"));
        System.out.println("city = "+storage.load("city"));
    }
}
