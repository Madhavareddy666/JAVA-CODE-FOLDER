public class Q35 {
    static abstract class Employee {
        String name; Employee(String name){this.name=name;}
        abstract double monthlyPay();
    }
    static class SalariedEmployee extends Employee {
        double salary; SalariedEmployee(String n,double s){super(n);salary=s;}
        double monthlyPay(){return salary;}
    }
    static class HourlyEmployee extends Employee {
        double rate,hours; HourlyEmployee(String n,double r,double h){super(n);rate=r;hours=h;}
        double monthlyPay(){return rate*hours;}
    }
    public static void main(String[] args) {
        Employee[] employees={new SalariedEmployee("Asha",45000),new HourlyEmployee("Vijay",250,160)};
        for(Employee e:employees)System.out.printf("%s monthly pay: %.2f%n",e.name,e.monthlyPay());
    }
}
