public class Q18 {
    static class Vehicle {
        protected double speed;
        Vehicle(double speed){this.speed=speed;}
        double tripTime(double distance){return distance/speed;}
    }
    static class Car extends Vehicle {
        double fuelEfficiency;
        Car(double speed,double fuelEfficiency){super(speed);this.fuelEfficiency=fuelEfficiency;}
        double estimateFuel(double distance){return distance/fuelEfficiency;}
        void showTrip(double distance){
            System.out.printf("Speed: %.1f km/h%n",super.speed);
            System.out.printf("Trip time: %.2f hours%n",super.tripTime(distance));
            System.out.printf("Estimated fuel: %.2f litres%n",estimateFuel(distance));
        }
    }
    public static void main(String[] args){new Car(60,15).showTrip(300);}
}
