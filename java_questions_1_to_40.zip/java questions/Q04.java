public class Q04 {
    static class Book {
        String title, author;
        Book() { title="Unknown"; author="Unknown"; }
        Book(String title, String author) { this.title=title; this.author=author; }
        void display() { System.out.println("Title: "+title+", Author: "+author); }
    }
    public static void main(String[] args) {
        Book first=new Book();
        Book second=new Book("Java Programming", "James Gosling");
        System.out.println("Default constructor:"); first.display();
        System.out.println("Parameterized constructor:"); second.display();
    }
}
