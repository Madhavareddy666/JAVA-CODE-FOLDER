public class Q27 {
    interface Notification { void send(String message); }
    static class Email implements Notification {
        public void send(String message){System.out.println("Email notification: "+message);}
    }
    static class SMS implements Notification {
        public void send(String message){System.out.println("SMS notification: "+message);}
    }
    public static void main(String[] args) {
        Notification[] notifications={new Email(),new SMS()};
        for(Notification n:notifications)n.send("Your practical class starts at 10 AM.");
    }
}
