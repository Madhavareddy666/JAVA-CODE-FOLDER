public class Q14 {
    interface Playable { void play(); }
    static class Guitar implements Playable {
        public void play(){System.out.println("Strumming the guitar strings.");}
    }
    static class Piano implements Playable {
        public void play(){System.out.println("Pressing the piano keys.");}
    }
    public static void main(String[] args) {
        Playable p=new Guitar();p.play();p=new Piano();p.play();
    }
}
