class Q41 {
    static class Person {
        String name;
        Person(String name) { this.name = name; }
    }
    static class Student extends Person {
        int id;
        double score;
        Student(String name, int id, double score) {
            super(name);
            this.id = id;
            this.score = score;
        }
        void printRecord() {
            System.out.println("Name: " + name);
            System.out.println("ID: " + id);
            System.out.println("Score: " + score);
            System.out.println("Status: " + (score >= 40 ? "Pass" : "Fail"));
        }
    }
    public static void main(String[] args) {
        Student student = new Student("Madhava Reddy", 161, 86.5);
        student.printRecord();
    }
}
