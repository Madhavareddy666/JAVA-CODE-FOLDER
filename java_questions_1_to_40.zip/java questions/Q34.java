public class Q34 {
    interface Payable { void pay(double amount); }
    static class CardPayment implements Payable {
        public void pay(double amount){System.out.printf("Card payment successful. Receipt: Rs. %.2f%n",amount);}
    }
    static class CashPayment implements Payable {
        public void pay(double amount){System.out.printf("Cash payment received. Receipt: Rs. %.2f%n",amount);}
    }
    public static void main(String[] args) {
        Payable card=new CardPayment(),cash=new CashPayment();
        card.pay(1250);cash.pay(500);
    }
}
