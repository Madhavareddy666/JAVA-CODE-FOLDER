import java.util.Scanner;
public class Q02 {
    static boolean isPrime(int n) {
        if (n < 2) return false;
        for (int i=2; i<=n/i; i++) if (n%i==0) return false;
        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter starting number: ");
        int start=sc.nextInt();
        System.out.print("Enter ending number: ");
        int end=sc.nextInt();
        System.out.println("Prime numbers:");
        for (int n=Math.min(start,end); n<=Math.max(start,end); n++)
            if (isPrime(n)) System.out.print(n+" ");
        System.out.println();
    }
}
