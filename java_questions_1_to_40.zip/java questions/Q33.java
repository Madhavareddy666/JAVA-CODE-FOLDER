public class Q33 {
    static abstract class Shape {
        abstract double area();
        abstract String description();
    }
    static class Circle extends Shape {
        double radius; Circle(double r){radius=r;}
        double area(){return Math.PI*radius*radius;}
        String description(){return "Circle with radius "+radius;}
    }
    static class Rectangle extends Shape {
        double length,width; Rectangle(double l,double w){length=l;width=w;}
        double area(){return length*width;}
        String description(){return "Rectangle "+length+" x "+width;}
    }
    public static void main(String[] args) {
        Shape[] shapes={new Circle(4),new Rectangle(5,3)};
        for(Shape s:shapes)System.out.printf("%s; area = %.2f%n",s.description(),s.area());
    }
}
