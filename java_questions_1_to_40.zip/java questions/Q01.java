public class Q01 {
    static class Student {
        String name; int rollNumber, age; double marks;
        Student(String name, int rollNumber, int age, double marks) {
            this.name=name; this.rollNumber=rollNumber; this.age=age; this.marks=marks;
        }
        void display() {
            System.out.println("Name: "+name+"\nRoll number: "+rollNumber+"\nAge: "+age+"\nMarks: "+marks);
        }
    }
    public static void main(String[] args) {
        Student s = new Student("Madhava Reddy", 161, 20, 89.5);
        s.display();
    }
}
