public class Q13 {
    abstract static class Appliance {
        abstract void turnOn();
        void plugIn(){System.out.println("Appliance is connected to the power source.");}
    }
    static class Fan extends Appliance {
        @Override void turnOn(){System.out.println("The fan is spinning.");}
    }
    public static void main(String[] args){Fan fan=new Fan();fan.plugIn();fan.turnOn();}
}
