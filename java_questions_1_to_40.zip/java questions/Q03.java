import java.util.Scanner;
public class Q03 {
    static class BankAccount {
        String holder; long accountNumber; double balance;
        BankAccount(String holder, long accountNumber, double balance) {
            this.holder=holder; this.accountNumber=accountNumber; this.balance=balance;
        }
        void deposit(double amount) {
            if (amount>0) { balance+=amount; System.out.println("Deposited: "+amount); }
            else System.out.println("Deposit amount must be positive.");
        }
        void withdraw(double amount) {
            if (amount<=0) System.out.println("Withdrawal amount must be positive.");
            else if (amount>balance) System.out.println("Insufficient balance.");
            else { balance-=amount; System.out.println("Withdrawn: "+amount); }
        }
        void checkBalance() { System.out.printf("Current balance: %.2f%n", balance); }
        void display() {
            System.out.println("Account holder: "+holder+"\nAccount number: "+accountNumber);
            checkBalance();
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        BankAccount account=new BankAccount("Madhava Reddy", 123456789L, 5000);
        account.display();
        System.out.print("Deposit amount: "); account.deposit(sc.nextDouble());
        System.out.print("Withdraw amount: "); account.withdraw(sc.nextDouble());
        account.display();
    }
}
