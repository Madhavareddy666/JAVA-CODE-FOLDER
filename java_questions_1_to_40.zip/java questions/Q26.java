public class Q26 {
    static abstract class Shape { abstract double area(); }
    static class Circle extends Shape {
        double radius; Circle(double r){radius=r;}
        @Override double area(){return Math.PI*radius*radius;}
    }
    static class Rectangle extends Shape {
        double length,width; Rectangle(double l,double w){length=l;width=w;}
        @Override double area(){return length*width;}
    }
    public static void main(String[] args) {
        Shape[] shapes={new Circle(3),new Rectangle(4,5),new Circle(2)};
        for(Shape s:shapes)System.out.printf("%s area: %.2f%n",s.getClass().getSimpleName(),s.area());
    }
}
