public class Q05 {
    static class Employee {
        private int id; private String name; private double salary;
        public void setId(int id) { if(id>0) this.id=id; else System.out.println("Invalid ID"); }
        public void setName(String name) { if(name!=null && !name.isBlank()) this.name=name; else System.out.println("Invalid name"); }
        public void setSalary(double salary) { if(salary>=0) this.salary=salary; else System.out.println("Invalid salary"); }
        public int getId() { return id; }
        public String getName() { return name; }
        public double getSalary() { return salary; }
    }
    public static void main(String[] args) {
        Employee e=new Employee(); e.setId(101); e.setName("Anil"); e.setSalary(45000);
        System.out.println("ID: "+e.getId()+"\nName: "+e.getName()+"\nSalary: "+e.getSalary());
    }
}
