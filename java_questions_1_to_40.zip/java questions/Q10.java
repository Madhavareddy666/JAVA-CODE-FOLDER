public class Q10 {
    static class Shape { }
    static class Circle extends Shape {
        double radius; Circle(double r){radius=r;}
        double area(){return Math.PI*radius*radius;}
    }
    static class Square extends Shape {
        double side; Square(double s){side=s;}
        double area(){return side*side;}
    }
    static class Rectangle extends Shape {
        double length,width; Rectangle(double l,double w){length=l;width=w;}
        double area(){return length*width;}
    }
    public static void main(String[] args) {
        System.out.printf("Circle area: %.2f%n",new Circle(5).area());
        System.out.printf("Square area: %.2f%n",new Square(4).area());
        System.out.printf("Rectangle area: %.2f%n",new Rectangle(6,3).area());
    }
}
