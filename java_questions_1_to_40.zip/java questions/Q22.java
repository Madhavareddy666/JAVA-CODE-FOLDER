public class Q22 {
    static class LibraryItem {
        String title; int itemLength;
        LibraryItem(String title,int itemLength){this.title=title;this.itemLength=itemLength;}
        void display(){System.out.println("Title: "+title+"\nLength: "+itemLength);}
    }
    static class Book extends LibraryItem {
        Book(String title,int pages){super(title,pages);}
        @Override void display(){System.out.println("Book");super.display();System.out.println("Pages: "+itemLength);}
    }
    static class Magazine extends LibraryItem {
        Magazine(String title,int pages){super(title,pages);}
        @Override void display(){System.out.println("Magazine");super.display();System.out.println("Pages: "+itemLength);}
    }
    public static void main(String[] args){new Book("Java Basics",250).display();new Magazine("Science Today",60).display();}
}
