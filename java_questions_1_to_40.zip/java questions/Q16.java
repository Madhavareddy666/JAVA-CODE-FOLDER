public class Q16 {
    static class Employee {
        private double salary;
        Employee(double salary){if(salary>=0)this.salary=salary;}
        void raiseSalary(){salary*=1.20;}
        public double getSalary(){return salary;} // Read-only outside the class
    }
    public static void main(String[] args) {
        Employee e=new Employee(50000);
        System.out.printf("Original salary: %.2f%n",e.getSalary());
        e.raiseSalary();
        System.out.printf("Salary after 20%% raise: %.2f%n",e.getSalary());
    }
}
