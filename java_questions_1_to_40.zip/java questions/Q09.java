public class Q09 {
    static class Employee {
        private int emp_id; private String name, dept; private double salary;
        Employee(int emp_id,String name,String dept,double salary) {
            this.emp_id=emp_id; this.name=name; this.dept=dept; this.salary=salary;
        }
        public int getEmpId(){return emp_id;} public void setEmpId(int id){if(id>0)emp_id=id;}
        public String getName(){return name;} public void setName(String n){if(n!=null&&!n.isBlank())name=n;}
        public String getDept(){return dept;} public void setDept(String d){if(d!=null&&!d.isBlank())dept=d;}
        public double getSalary(){return salary;} public void setSalary(double s){if(s>=0)salary=s;}
    }
    public static void main(String[] args) {
        Employee e=new Employee(101,"Ravi","IT",50000);
        System.out.println("Employee ID: "+e.getEmpId()+"\nName: "+e.getName()+
            "\nDepartment: "+e.getDept()+"\nSalary: "+e.getSalary());
    }
}
