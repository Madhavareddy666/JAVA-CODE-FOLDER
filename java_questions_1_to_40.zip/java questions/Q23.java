public class Q23 {
    static class Appliance {
        double powerWatts;
        Appliance(double powerWatts){this.powerWatts=powerWatts;}
        double energyKWh(double hours){return powerWatts*hours/1000.0;}
    }
    static class WashingMachine extends Appliance {
        double capacityKg;
        WashingMachine(double watts,double capacityKg){super(watts);this.capacityKg=capacityKg;}
        double waterUsage(double cycles){return capacityKg*10*cycles;}
    }
    public static void main(String[] args) {
        WashingMachine w=new WashingMachine(500,7);
        System.out.printf("Energy for 2 hours: %.2f kWh%n",w.energyKWh(2));
        System.out.printf("Water for 2 cycles: %.1f litres%n",w.waterUsage(2));
    }
}
