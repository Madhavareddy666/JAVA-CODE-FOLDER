public class Q20 {
    static class Shape { }
    static class Circle extends Shape {
        double radius; Circle(double r){radius=r;}
        double area(){return Math.PI*radius*radius;}
        double circumference(){return 2*Math.PI*radius;}
    }
    public static void main(String[] args) {
        Circle c=new Circle(7);
        System.out.printf("Area: %.2f%nCircumference: %.2f%n",c.area(),c.circumference());
    }
}
