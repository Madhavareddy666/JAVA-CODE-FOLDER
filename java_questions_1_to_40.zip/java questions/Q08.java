public class Q08 {
    static class Animal { void sound() { System.out.println("Animal sound"); } }
    static class Dog extends Animal { @Override void sound() { System.out.println("Dog barks"); } }
    static class Cat extends Animal { @Override void sound() { System.out.println("Cat meows"); } }
    public static void main(String[] args) {
        Animal a=new Dog(); a.sound();
        a=new Cat(); a.sound();
    }
}
