# Java Practical Questions (1–40)

This folder contains one independent Java source file for each practical question:
`Q01.java` through `Q40.java`.

## Open in VS Code
1. Extract/open this folder in Visual Studio Code.
2. Install a JDK (Java 17 or later recommended) and the VS Code **Extension Pack for Java**.
3. Open a terminal in this folder.
4. Compile a program: `javac Q01.java`
5. Run it: `java Q01`

Each file has its own `public class Qxx` and can be compiled/run independently.

## Run all programs
On Windows PowerShell:
```powershell
1..40 | ForEach-Object { javac ("Q{0:D2}.java" -f $_); if ($LASTEXITCODE -eq 0) { java ("Q{0:D2}" -f $_) } }
```
Question 2 and Question 3 read input from the keyboard. For a quick test, enter values when prompted.

## Notes
- Sample values are used in most programs so they run immediately.
- Questions 18–19 were interpreted from the handwritten pages as Vehicle/Car trip speed, time and fuel-estimation exercises; adjust the sample fields/formulas if your teacher intended a different specification.
- The handwritten question pages 16–40 contain short prompts. The programs follow the readable wording in those images.

## Important source-PDF note
The second uploaded PDF contains questions 16, 17, 18, then jumps directly to 20 and continues through 41. It does not show question 19. Therefore `Q19.java` is a runnable notice file, not a solution to an unknown prompt. The PDF's last page contains question 41; its implementation is included separately as `Q41_extra.java` (compile with `javac Q41_extra.java`, then run `java Q41`).
