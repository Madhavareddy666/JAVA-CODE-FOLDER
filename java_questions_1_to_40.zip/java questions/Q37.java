public class Q37 {
    static abstract class LibraryItem {
        int daysLate; LibraryItem(int days){daysLate=Math.max(0,days);}
        abstract double lateFee();
    }
    static class Book extends LibraryItem {
        Book(int days){super(days);}
        double lateFee(){return Math.min(daysLate*2.0,100);}
    }
    static class DVD extends LibraryItem {
        DVD(int days){super(days);}
        double lateFee(){return Math.min(daysLate*5.0,200);}
    }
    public static void main(String[] args) {
        System.out.println("Book late fee: Rs. "+new Book(12).lateFee());
        System.out.println("DVD late fee: Rs. "+new DVD(12).lateFee());
    }
}
