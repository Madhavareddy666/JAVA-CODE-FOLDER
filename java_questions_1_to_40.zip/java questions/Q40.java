import java.util.List;
public class Q40 {
    interface Portable { void print(); }
    static abstract class Document {
        String title; Document(String title){this.title=title;}
        abstract double total();
    }
    static class Invoice extends Document implements Portable {
        List<String> items; List<Double> prices;
        Invoice(String title,List<String> items,List<Double> prices){super(title);this.items=items;this.prices=prices;}
        double total(){double sum=0;for(double p:prices)sum+=p;return sum;}
        public void print(){
            System.out.println("Invoice: "+title);
            for(int i=0;i<items.size();i++)System.out.printf("%s: Rs. %.2f%n",items.get(i),prices.get(i));
            System.out.printf("Total: Rs. %.2f%n",total());
        }
    }
    public static void main(String[] args) {
        Invoice invoice=new Invoice("Java Lab",List.of("Notebook","Pen","File"),List.of(80.0,10.0,40.0));
        Portable printable=invoice;printable.print();
    }
}
