# Compile and run each practical one by one (Windows PowerShell)
for ($i = 1; $i -le 40; $i++) {
    $class = "Q{0:D2}" -f $i
    Write-Host "`n===== $class =====" -ForegroundColor Cyan
    javac "$class.java"
    if ($LASTEXITCODE -eq 0) { java $class }
    if ($i -eq 2 -or $i -eq 3) {
        Write-Host "This program needs keyboard input; run it separately for interactive testing."
        break
    }
}
