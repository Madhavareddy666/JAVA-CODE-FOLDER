public class Q24 {
    static class User {
        String name; String membership;
        User(String name,String membership){this.name=name;this.membership=membership;}
        String membershipSummary(){return name+" has "+membership+" membership.";}
    }
    static class PremiumUser extends User {
        int rewardPoints;
        PremiumUser(String name,int points){super(name,"Premium");rewardPoints=points;}
        @Override String membershipSummary(){return super.membershipSummary()+" Reward points: "+rewardPoints;}
    }
    public static void main(String[] args){System.out.println(new PremiumUser("Arun",1200).membershipSummary());}
}
