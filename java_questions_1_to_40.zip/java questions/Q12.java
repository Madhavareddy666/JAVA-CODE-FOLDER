public class Q12 {
    static class Vehicle {
        String brand;
        void start(){System.out.println("The vehicle is starting");}
    }
    static class Car extends Vehicle {
        String modelName;
        void accelerate(){System.out.println("The car is accelerating");}
    }
    public static void main(String[] args) {
        Car car=new Car(); car.brand="Toyota"; car.modelName="Innova";
        System.out.println("Brand: "+car.brand+"\nModel: "+car.modelName);
        car.start(); car.accelerate();
    }
}
