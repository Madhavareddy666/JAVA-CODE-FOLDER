public class Q28 {
    interface Payment { double processingFee(double amount); }
    static class CardPayment implements Payment {
        public double processingFee(double amount){return amount*0.02+5;}
    }
    static class UpiPayment implements Payment {
        public double processingFee(double amount){return amount*0.005;}
    }
    static class CashPayment implements Payment {
        public double processingFee(double amount){return 0;}
    }
    public static void main(String[] args) {
        Payment[] methods={new CardPayment(),new UpiPayment(),new CashPayment()};
        String[] names={"Card","UPI","Cash"}; double amount=1000;
        for(int i=0;i<methods.length;i++)
            System.out.printf("%s processing fee: %.2f%n",names[i],methods[i].processingFee(amount));
    }
}
