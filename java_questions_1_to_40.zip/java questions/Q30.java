public class Q30 {
    static class AreaCalculator {
        double area(double side){return side*side;}
        double area(double length,double width){return length*width;}
        double area(int radius){return Math.PI*radius*radius;}
    }
    public static void main(String[] args) {
        AreaCalculator a=new AreaCalculator();
        System.out.println("Square area: "+a.area(4.0));
        System.out.println("Rectangle area: "+a.area(5.0,3.0));
        System.out.printf("Circle area: %.2f%n",a.area(7));
    }
}
