public class Q32 {
    interface Discount { double apply(double price); }
    static class FixedDiscount implements Discount {
        double amount; FixedDiscount(double a){amount=a;}
        public double apply(double price){return Math.max(0,price-amount);}
    }
    static class PercentageDiscount implements Discount {
        double percent; PercentageDiscount(double p){percent=p;}
        public double apply(double price){return price*(1-percent/100);}
    }
    public static void main(String[] args) {
        double originalPrice=2000;
        Discount[] discounts={new FixedDiscount(200),new PercentageDiscount(10)};
        for(Discount d:discounts)System.out.printf("Discounted price: %.2f%n",d.apply(originalPrice));
    }
}
