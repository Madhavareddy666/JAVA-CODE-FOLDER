public class Q11 {
    static class Parent { void fun(){System.out.println("Parent fun() method");} }
    static class Child extends Parent {
        @Override void fun(){super.fun(); System.out.println("Child fun() method");}
    }
    public static void main(String[] args){new Child().fun();}
}
