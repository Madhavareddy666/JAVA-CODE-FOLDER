public class Q25 {
    static class Animal { void speak(){System.out.println("Animal makes a sound.");} }
    static class Dog extends Animal { @Override void speak(){System.out.println("Dog barks.");} }
    static class Cat extends Animal { @Override void speak(){System.out.println("Cat meows.");} }
    public static void main(String[] args) {
        Animal[] animals={new Dog(),new Cat()};
        for(Animal animal:animals)animal.speak();
    }
}
